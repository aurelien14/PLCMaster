/* Static configuration stub implementation. TODO: load and manage static configuration. */

#include "app/config/config_static.h"
//#define FAKE_DEV


static const BackendConfig_t kBackendConfigs[] = {
	{
		.type = BACKEND_TYPE_ETHERCAT,
		.name = "ec0",
		.ifname = "\\Device\\NPF_{FB092E67-7CA1-4E8F-966D-AC090D396487}",
		.cycle_time_us = 1000,
		.dc_clock = true,
		.period_ns = 0,
		.spin_threshold_ns = 0,
		.rt_priority = PLAT_THREAD_PRIORITY_HIGH,
		.rt_affinity_cpu = -1,
		.rt_reserved_cpu = -1,
		.rt_timer_resolution_ms = 1,
	},
};

static const DeviceConfig_t kDeviceConfigs[] = {
#if defined FAKE_DEV
	{
		.name = "CPU_IO",
		.model = "FakEcatDev",
		.backend = "ec0",
		.ethercat =
			{
				.expected_position = 1,
			},
		.io_addr = 1,
		.expected_identity =
			{
				.vendor_id = 0x1234567,
				.product_code = 0x123,
				},
	},
#else
	{
		.name = "CPU_IO",
		.model = "L230",
		.backend = "ec0",
		.ethercat =
			{
				.expected_position = 1,
			},
		.io_addr = 1,
		.expected_identity =
			{
				.vendor_id = 0x47535953,
				.product_code = 0x3213335,
			},
	},
#endif
};

static const ProcessVarDesc_t kProcessVarDescs[] = {
	{
		.name = "temp_sp",
		.type = TAG_T_REAL,
		.initial = {.f = 20.0f},
	},
	{
		.name = "run_cmd",
		.type = TAG_T_BOOL,
		.initial = {.b = false},
	},
	{
		.name = "alarm_code",
		.type = TAG_T_U16,
		.initial = {.u16 = 0},
	},
};

static const HmiTagDesc_t kHmiTagDescs[] = {
	{
		.name = "temp_setpoint",
		.alias_of = "proc.temp_sp",
		.access = HMI_RW,
	},
	{
		.name = "run",
		.alias_of = "proc.run_cmd",
		.access = HMI_RW,
	},
	{
		.name = "alarm_code",
		.alias_of = "proc.alarm_code",
		.access = HMI_RO,
	},
};

static const SystemConfig_t kStaticConfig = {
	.backends = kBackendConfigs,
	.backend_count = sizeof(kBackendConfigs) / sizeof(kBackendConfigs[0]),
	.devices = kDeviceConfigs,
	.device_count = sizeof(kDeviceConfigs) / sizeof(kDeviceConfigs[0]),
	.process_vars = kProcessVarDescs,
	.process_var_count = sizeof(kProcessVarDescs) / sizeof(kProcessVarDescs[0]),
	.hmi_tags = kHmiTagDescs,
	.hmi_tag_count = sizeof(kHmiTagDescs) / sizeof(kHmiTagDescs[0]),
};

const SystemConfig_t *get_static_config(void)
{
	return &kStaticConfig;
}
