/* EtherCAT diagnostics. */

#ifndef ETHERCAT_DIAG_H
#define ETHERCAT_DIAG_H

#include "core/runtime/runtime.h"

void ethercat_diag_print(const Runtime_t *rt);

#endif /* ETHERCAT_DIAG_H */
