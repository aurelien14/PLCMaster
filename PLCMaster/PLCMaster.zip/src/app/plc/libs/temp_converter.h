#ifndef TEMP_CONVERTER_H
#define TEMP_CONVERTER_H

float pt100_resistance_to_temperature(float resistance);

#endif // !TEMP_CONVERTER_H
