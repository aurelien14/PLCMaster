/* Modbus backend stub implementation. TODO: implement Modbus communication handling. */

#include "mb_backend.h"

int mb_backend_init(void)
{
    return -1;
}

int mb_backend_shutdown(void)
{
    return -1;
}
