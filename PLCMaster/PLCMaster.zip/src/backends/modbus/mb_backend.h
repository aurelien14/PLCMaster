/* Modbus backend declarations. TODO: define Modbus backend operations. */

#ifndef MB_BACKEND_H
#define MB_BACKEND_H

int mb_backend_init(void);
int mb_backend_shutdown(void);

#endif /* MB_BACKEND_H */
