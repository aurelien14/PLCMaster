/* Tag ID definitions. */

#ifndef TAG_ID_H
#define TAG_ID_H

#include <stdint.h>

typedef uint32_t TagId_t; /* 0 = invalid */

#endif /* TAG_ID_H */
