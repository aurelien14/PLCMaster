#ifndef PLATFORM_MEM_H
#define PLATFORM_MEM_H

#include "platform_detect.h"

int plat_mem_lock_all(void);

#endif /* PLATFORM_MEM_H */
