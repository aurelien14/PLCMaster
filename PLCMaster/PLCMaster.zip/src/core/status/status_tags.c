/* Status tags stub implementation. TODO: provide status tag mapping. */

#include "status_tags.h"

#include <stddef.h>

int status_tags_init(void)
{
    return -1;
}

const char *status_tags_lookup(int code)
{
    (void)code;
    return NULL;
}
