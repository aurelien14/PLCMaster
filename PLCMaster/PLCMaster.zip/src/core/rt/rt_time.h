/* Real-time timing utilities interface. TODO: specify RT timing contracts. */

#ifndef RT_TIME_H
#define RT_TIME_H

int rt_time_init(void);
long rt_time_now(void);

#endif /* RT_TIME_H */
