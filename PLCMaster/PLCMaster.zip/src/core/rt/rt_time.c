/* Real-time timing stub implementation. TODO: provide real timing sources. */

#include "rt_time.h"

int rt_time_init(void)
{
    return -1;
}

long rt_time_now(void)
{
    return -1;
}
